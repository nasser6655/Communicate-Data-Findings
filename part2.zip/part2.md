# We will determine the reasons that encourage the borrower to take the loan

## Investigation Overview

I'll look in the relationship between prosper rating, APR, loan term, and monthly income with the laon amount.

## Dataset Overview
The dataset consisted of borrower APRs and attributes of 113,937 loans. The attributes included original loan amount, borrower's Prosper rating, loan term, borrower's stated monthly income, as well as many other features such as borrower's employment status, debt to income ratio, current loan status etc. 352 data points were removed from the analysis due to very large stated monthly income seemed as outliers and missing borrower APR information.


```python
# import all packages and set plots to be embedded inline
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb

%matplotlib inline

# suppress warnings from final output
import warnings
warnings.simplefilter("ignore")
```


```python
# load data
df = pd.read_csv('prosperLoanData.csv')
```


```python
#  ProsperRating (alpha) into ordered categorical types
ordinal_var_dict = {'ProsperRating (Alpha)': ['AA','A','B','C','D','E','HR']}

for var in ordinal_var_dict:
    ordered_var = pd.api.types.CategoricalDtype(ordered = True,
                                                categories = ordinal_var_dict[var])
    df[var] = df[var].astype(ordered_var)
```


```python
# Subset the dataframe by selecting features of interest
features = ['LoanOriginalAmount', 'BorrowerAPR', 'StatedMonthlyIncome', 'Term', 'ProsperRating (Alpha)', 
        'EmploymentStatus']
df1 = df[features]

# data wrangling, remove loans with missing borrower APR information
df1 = df1.dropna()
df1.shape
```




    (84853, 6)



## Distribute a list of reasons for taking the loan

The APR distribution looks roughly bimodal, with one very sharp peak at about 0.35.


```python
# start with a standard-scaled plot
binsize = 0.01
bins = np.arange(0, df1.BorrowerAPR.max()+binsize, binsize)
plt.figure(figsize=[8, 5])
plt.hist(data = df1, x = 'BorrowerAPR', bins = bins);
plt.xlabel('APR');
plt.title('Histogram for APR')

```




    Text(0.5, 1.0, 'Histogram for APR')




    
![png](output_7_1.png)
    



```python
numeric_vars = ['LoanOriginalAmount', 'BorrowerAPR', 'StatedMonthlyIncome']
categoric_vars = ['Term', 'ProsperRating (Alpha)', 'EmploymentStatus']


```

## Distribution of Original Loan Amount

There are very large spikes in frequency at the bars with multiples of 5K (e.g. 10K, 15K, 20K); frequency quickly trails off until the next spike.


```python
binsize = 500
bins = np.arange(8000, df1.LoanOriginalAmount.max()+binsize, binsize)
plt.figure(figsize=[8, 5])
plt.hist(data = df1, x = 'LoanOriginalAmount', bins = bins);
plt.xlabel('Original loan amount ($)');
plt.title('Histogram for Original loan amount ($)')

```




    Text(0.5, 1.0, 'Histogram for Original loan amount ($)')




    
![png](output_10_1.png)
    


## Borrower APR vs. Loan Amount

This plot shows that borrower APR is negatively correlated with loan amount.


```python
plt.figure(figsize = [8, 6])
sb.regplot(data = df1, x = 'LoanOriginalAmount', y = 'BorrowerAPR', scatter_kws={'alpha':0.01});
```


    
![png](output_12_0.png)
    


##  loan original amount, monthley income and APR correlatation with the categorical variables

Interestingly, it show that there is a postive relationships between the loan amount and the loan term. The APR become lower with higher rating, meaning that having high rating can result in lower APR.


```python
# plot matrix of numeric features against categorical features.

def boxgrid(x, y, **kwargs):
    """ Quick hack for creating box plots with seaborn's PairGrid. """
    default_color = sb.color_palette()[0]
    sb.boxplot(x, y, color = default_color)
    
plt.figure(figsize = [10, 10])
g = sb.PairGrid(data = df1, y_vars = ['BorrowerAPR', 'StatedMonthlyIncome', 'LoanOriginalAmount'], 
                x_vars = categoric_vars, size = 3, aspect = 1.5)
g.map(boxgrid);
plt.xticks(rotation=30);
```


    <Figure size 720x720 with 0 Axes>



    
![png](output_14_1.png)
    


##  Prosper Rating Effect on Relationship between APR and Loan Amount

There seems to be a realationship between rating and loan amount, the higher the rating the higher the loan amount become, and with higher rating comes a lower APR, showing that people with AA or A borrow more money compare to the rest, increasing the APR can help reduce AA or A people.


```python
# Prosper rating effect on relationship of APR/ loan amount
g=sb.FacetGrid(data=df1, col='ProsperRating (Alpha)', col_wrap=4)
g.map(sb.regplot, 'LoanOriginalAmount', 'BorrowerAPR', x_jitter=0.04, scatter_kws={'alpha':0.1});
g.add_legend();
```


    
![png](output_16_0.png)
    


##  Borrower APR by Rating and Term

A dodged point plot shows that a borrwer with HR/C rating are having a higher APR,AA and A have lower APR. This demonstrate that by having a high rating you can have a lower APR.


```python
fig = plt.figure(figsize = [8,6])
ax = sb.pointplot(data = df1, x = 'ProsperRating (Alpha)', y = 'BorrowerAPR', hue = 'Term',
           palette = 'Blues', linestyles = '', dodge = 0.4, ci='sd')
plt.title('Borrower APR across rating and term')
plt.ylabel('Mean Borrower APR')
ax.set_yticklabels([],minor = True);
```


    
![png](output_18_0.png)
    



```python
!jupyter nbconvert part2.ipynb --to slides --no-input --no-prompt
```

    [NbConvertApp] Converting notebook part2.ipynb to slides
    [NbConvertApp] Writing 972975 bytes to part2.slides.html
    


```python
!jupyter nbconvert "part2.ipynb" --to slides --post serve --no-input --no-prompt
```

    [NbConvertApp] Converting notebook part2.ipynb to slides
    [NbConvertApp] Writing 972975 bytes to part2.slides.html
    [NbConvertApp] Redirecting reveal.js requests to https://cdnjs.cloudflare.com/ajax/libs/reveal.js/3.5.0
    Traceback (most recent call last):
      File "D:\1111\Scripts\jupyter-nbconvert-script.py", line 10, in <module>
        sys.exit(main())
      File "D:\1111\lib\site-packages\jupyter_core\application.py", line 270, in launch_instance
        return super(JupyterApp, cls).launch_instance(argv=argv, **kwargs)
      File "D:\1111\lib\site-packages\traitlets\config\application.py", line 845, in launch_instance
        app.start()
      File "D:\1111\lib\site-packages\nbconvert\nbconvertapp.py", line 350, in start
        self.convert_notebooks()
      File "D:\1111\lib\site-packages\nbconvert\nbconvertapp.py", line 524, in convert_notebooks
        self.convert_single_notebook(notebook_filename)
      File "D:\1111\lib\site-packages\nbconvert\nbconvertapp.py", line 491, in convert_single_notebook
        self.postprocess_single_notebook(write_results)
      File "D:\1111\lib\site-packages\nbconvert\nbconvertapp.py", line 463, in postprocess_single_notebook
        self.postprocessor(write_results)
      File "D:\1111\lib\site-packages\nbconvert\postprocessors\base.py", line 28, in __call__
        self.postprocess(input)
      File "D:\1111\lib\site-packages\nbconvert\postprocessors\serve.py", line 90, in postprocess
        http_server.listen(self.port, address=self.ip)
      File "D:\1111\lib\site-packages\tornado\tcpserver.py", line 151, in listen
        sockets = bind_sockets(port, address=address)
      File "D:\1111\lib\site-packages\tornado\netutil.py", line 174, in bind_sockets
        sock.bind(sockaddr)
    OSError: [WinError 10048] Only one usage of each socket address (protocol/network address/port) is normally permitted
    


```python

```
